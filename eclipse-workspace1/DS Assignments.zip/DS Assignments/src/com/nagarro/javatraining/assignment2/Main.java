package com.nagarro.javatraining.assignment2;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in=new Scanner(System.in);
		System.out.print("Enter Initial Size of Stack : ");
		int n=in.nextInt();
		Stack_Functions <Integer> sf=new Stack_Functions <Integer>(n);
			while(true) {
			System.out.println("1. Push ");
			System.out.println("2. Pop ");
			System.out.println("3. Peek ");
			System.out.println("4. Contains ");
			System.out.println("5. Size ");
			System.out.println("6. Reverse ");
			System.out.println("7. Iterator ");
			System.out.println("8. Print/Traverse ");
			System.out.println("9. Terminated");
			int choice;
				try {
					choice=in.nextInt();
				}
				catch(InputMismatchException e) {
					System.out.println("Number is required : Enter Valide Input ");
					in.nextLine();
					continue;
				}
			switch(choice) {
				case 1:
					/************* Calling push Function **************************************/
					System.out.println("Enter items which you want to push into stack : ");
						sf.push(in.nextInt());
					break;
				
				case 2:
					
					/**************** Calling Pop Function ***********************************/
					System.out.println("Popped Item : "+sf.pop());	
					break;
					
					
				case 3:
					System.out.print("Peek Item of Stack : ");
					int result=sf.peek();
					System.out.println(result);
					break;
				
				case 4:
					/**************** Calling Contains Function *****************************/
					System.out.print("Enter item which you want to be check : ");
					int item =in.nextInt();
					System.out.println("Contains Item : "+sf.contains(item));
					break;
				
				case 5:
					/************** Calling Size Function ************************************/
						System.out.println("Size of Stack : "+sf.stack_size());
						break;
				
				case 6:

					/**********************  Calling reverse function ***********************/
					sf.reverse();
					break;
				
				case 7: 
					/********************* Calling Iterator Function ************************/
					System.out.print("Print Items Using �terator : ");
					for(Iterator i=sf.iterator(); i.hasNext();) {
						System.out.print(i.next()+" ");
					}
					System.out.println();
					break;
				
				case 8:
					
					/********************** Calling Print Function  *************************/
						   sf.print_stack_element();
						   break;
						  
				case 9:
					System.out.println("Terminated .......");
					System.exit(0);
				default:
					System.out.println("Enter a valid choice ");		
					continue;
			}
			System.out.println("Do You want to Quit Enter 0 or 1");
		     int choice1=in.nextInt();
		     if(choice1==0){   
		    	 System.out.println("Thank You");
		    	 in.close();
		    	 break;
		     
		     }
		     else{	 
		    	 continue;
		     }
			
		}
		
			  
	}

}
