package com.nagarro.javatraining.assignment2;


import java.util.Iterator;
import java.util.NoSuchElementException;
class Stack_Functions<T extends Object> implements Iterable <T>{
	int stackpointer=0;
	int maxsize;
	private T[] data;
	private T[] reversed_list;
	public Stack_Functions(int size){
		this.maxsize=size;
		this.data=(T[]) new Object[maxsize];
		
	}

/**************************** Push Item Into Stack ****************************/
	public void push(T item) {
		if(stackpointer>maxsize) {
			throw new IndexOutOfBoundsException("Stack is full you can't push no more item into stack");
		}
		else
			data[stackpointer++]=item;
	}

/************************ Pop Item from Stack **********************************/
	public T pop() {
		if(stackpointer==0)
			throw new IllegalStateException("No more items on the stack");
		return data[--stackpointer];
}

/************************* Size Function ***************************************/
	public int stack_size() {
		if(stackpointer==0)
			throw new IllegalStateException("Stack is Empty");
		return stackpointer;
}

/********************* Contains Function ***************************************/
	public boolean contains(T item) {
		boolean found=false;
		for(int i=0; i<stack_size(); i++) {
			if(data[i]==item)
			{
				found=true;
				break;
			}
		}
		return found;
	}

/**************************** Peek Function *************************************/
	public T peek() {
		if(stackpointer==0)
			throw new IllegalStateException("No peek element is present in stack because stack is empty");
		return data[stackpointer-1];
	}
	
/*************************** Reverse Function ***********************************/
	public void print_stack_element() {
		this.reversed_list=(T[]) new Object[stackpointer];
		int top=stackpointer;
		for(int i=0; i<reversed_list.length; i++) {
			reversed_list[i]=data[--top];
		}
		System.out.print("List Items : ");
		for(int i=0; i<reversed_list.length; i++)
			System.out.print(reversed_list[i]+" ");
		System.out.println();
	}

/**************************** Iterator Function **********************************/
	 public Iterator iterator() {
			Iterator it=new Iterator() {
		int temp=stackpointer;
		public boolean hasNext() {
			return temp!=0;
		}
		public Object next() {
			temp=temp-1;
			return data[temp];
		}
		
	};
	return it;
}
	
/************************ Print Stack Element Function **************************/
    public void reverse() {
    	if(stackpointer==0)
    		throw new IllegalStateException("Stack is Empty");
    	System.out.print("Reverse Items : ");
    	for(int i=0; i<stackpointer; i++)
    		System.out.print(data[i]+" ");
    	System.out.println();
    }
    
   
    }
