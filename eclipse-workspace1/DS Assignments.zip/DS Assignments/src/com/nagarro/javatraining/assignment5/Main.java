package com.nagarro.javatraining.assignment5;

import java.util.InputMismatchException;
import java.util.Scanner;

public  class Main{

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		GenericTree<Integer> tree = new GenericTree<Integer>();

		while (true) {
			System.out.println("Enter Your Choice ");
			System.out.println("1. Insert ");
			System.out.println("2. Delete ");
			System.out.println("3. Contains ");
			System.out.println("4. Get elements by value ");
			System.out.println("5. Get elements by level ");
			System.out.println("6. Iterator Breadth first");
			System.out.println("7. Iterator Depth first");
			System.out.println("8. Print Breadth first");
			System.out.println("9. Print Depth first");
			System.out.println("10. Exit");

			int choice = 100;
			try {
				choice = sc.nextInt();
			} catch (InputMismatchException e) {
				System.out.println("Number is required : INVALID INPUT ");
				sc.nextLine();
				continue;
			}

			switch (choice) {
			case 1:
				System.out.print("Enter data : ");
				int data = 0;
				int parent = sc.nextInt();
				data = sc.nextInt();
				tree.insert(data, parent);
				
				break;
			case 2:
				System.out.println("Enter data which you want to be delete : ");
				data = sc.nextInt();
				tree.delete(data);
				break;
			case 3:
				data = sc.nextInt();
				System.out.println(	"Tree Contains Data : "+tree.contains(data));
				break;
			case 4:
				System.out.println("Enter data : ");
				int contains_data = sc.nextInt();
				System.out.println("Get data by Value : ");
				tree.getElementsByValue(contains_data);
			
				break;
			case 5:
				System.out.println("Enter level: ");
				int level = sc.nextInt();
				System.out.println("Get data of Level : "+level);
				tree.getElementsByLevel(level);
				break;
			case 6:
				System.out.println("Data After Iterating breadth : ");
				tree.iteratorBreadth();
				;
				break;
			case 7:
				System.out.println("Data After Iterating Depth : ");
				tree.iteratorDepth();
				;
				break;
			case 8:
				System.out.print("Data After Traversing Breadth : ");
				tree.traverseBreadth();
				break;
			case 9:
				System.out.print("Data After Traversing Depth : ");
				tree.traverseDepth();
				break;
			case 10:
				System.out.println("Terminated");
				System.exit(0);
			}
			
			System.out.println("Do You want to Quit Enter 0 or 1");
		     int choice1=sc.nextInt();
		     if(choice1==0){   
		    	 System.out.println("Thank You");
		    	 sc.close();
		    	 break;
		     
		     }
		     else{	 
		    	 continue;
		     }
		}
	}
}

