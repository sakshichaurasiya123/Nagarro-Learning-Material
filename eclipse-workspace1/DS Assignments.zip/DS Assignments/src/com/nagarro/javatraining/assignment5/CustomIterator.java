package com.nagarro.javatraining.assignment5;


import java.util.Iterator;
public class CustomIterator<X> implements Iterator<X> {
	Queue<X> root=null;
    public CustomIterator(Queue<X> queueIterator) {
       this.root=queueIterator;
    }

    @Override
    public boolean hasNext() {
        
        if(this.root==null || root.length()==0)
        {
            return false;
        }
        else {
            return true;
        }
    }

    @Override
    public X next() {
        // TODO Auto-generated method stub
        X data=null;
        try{
        data= this.root.dequeue();
        }
        catch(Exception e) {
            
        }
        return data;
    }

}
