package com.nagarro.javatraining.assignment5;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Scanner;

public class GenericTree<X> extends Function<X> implements Iterable<X> {

	Queue<X> iteratorDepth;
	Queue<X> iteratorBreadth;
	TreeNode<X> root;
	int size;

/*****************************************  Default constructor ********************************************************/
	public GenericTree() 
	{
		iteratorDepth = new Queue<X>();
		iteratorBreadth = new Queue<X>();
		this.root = null;
		size = 0;
	}
	
/************************************************** Insert Method *************************************************/
	public void insert(X data, X parent) {
		try {
			if (root == null) {
				TreeNode<X> childNode = new TreeNode<X>();
				childNode.parent = null;
				childNode.data = data;
				root = childNode;
				size++;
				return;
			}
			TreeNode<X> parentNode = findNode(parent);
			TreeNode<X> childNode = new TreeNode<X>();
			if (parentNode != null) {
				childNode.parent = parentNode;
				childNode.data = data;
				parentNode.children.add(childNode);
				size++;
				return;
			}

			throw new Exception("Parent is not present");
			
		} catch (Exception e) {
			System.out.println(e);
		}
	}

/******************************************* Traverse Depth Method *****************************************************/
	public void traverseDepth()
	{
		try {
			if (root == null) {
				throw new Exception("Tree is empty!");
			} else {
				traverseDepth(root);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

/************************************** Print value based on level Function **********************************************/
	public void getElementsByLevel(int level) 
	{
		try {
			if (level < 0) {
				throw new Exception("Level can't be negative");
			}
			if (root == null) {
				throw new Exception("Can't find elements.tree is empty!");
			}

			Queue<TreeNode<X>> queue = new Queue<>();
			queue.enqueue(root);
			queue.enqueue(null);
			int count = 0;
			String value = "";
			while (queue.length() != 0) {
				TreeNode<X> temp = queue.dequeue();
				if (temp != null) {
					value = value + temp.data + " ";
					for (int i = 0; i < temp.children.size(); i++) {
						ArrayList<TreeNode<X>> child = temp.children;
						queue.enqueue(child.get(i));
					}
				} else {
					if (queue.length() != 0) {
						queue.enqueue(null);
					}
					if (level == count) {
						break;
					}
					count++;
					value = "";
				}
			}
			if (value == "") {
				throw new Exception("Not found");
			} else {
				System.out.println(value);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

/*****************************************************  traverse Depth Function *****************************************/
	private void traverseDepth(TreeNode<X> node) {

		String values = node.data + ":";
		for (int i = 0; i < node.children.size(); i++) {
			if (i == node.children.size() - 1)
				values += node.children.get(i).data;
			else
				values += node.children.get(i).data + ",";
		}
		System.out.println(values);
		for (int i = 0; i < node.children.size(); i++) {
			ArrayList<TreeNode<X>> child = node.children;
			traverseDepth(child.get(i));
		}
	}
	
/******************************************** Traverse Breadth Function ************************************************/
	public void traverseBreadth() // This method used to traverse the breadth first
	{
		try {
			if (root != null) {
				Queue<TreeNode<X>> queue = new Queue<>();
				queue.enqueue(root);
				while (queue.length() != 0) {
					TreeNode<X> temp = queue.dequeue();
					String values = temp.data + ":";

					for (int i = 0; i < temp.children.size(); i++) {
						ArrayList<TreeNode<X>> child = temp.children;
						values += child.get(i).data + " ";
						queue.enqueue(child.get(i));
					}
					System.out.println(values);

				}
			} else {
				throw new Exception("GenericTree is empty");
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

/************************************************** Find Node Function ************************************************/
	public TreeNode<X> findNode(X nodeData) {
		// TODO Auto-generated method stub
		return findNode(nodeData, root);
	}

	private TreeNode<X> findNode(X nodeData, TreeNode<X> root) {

		if (root.data == nodeData) {
			return root;
		}
		for (int i = 0; i < root.children.size(); i++) {
			ArrayList<TreeNode<X>> child = root.children;
			TreeNode<X> node = findNode(nodeData, child.get(i));
			if (node != null) {
				return node;
			}
		}
		return null;
	}

/******************************************** Delete Function **********************************************************/	
	public void delete(X data) // This method is used to delete the data in tree
	{
		try {
			TreeNode<X> node = findNode(data);
			if (node != null) {
				node.parent.children.remove(node);
				size--;
				System.out.println("Deleted Data : "+data);
				return;
			}
			throw new Exception("Node is not present in the tree");
			
			
		} catch (Exception e) {
			System.out.println(e);
		}
	}

/******************************************** Contains Method **********************************************************/
	public boolean contains(X data) // This method is used to check data present or not
	{
		TreeNode<X> node = findNode(data);
		if (node == null) {
			return false;
		} else
			return true;
	}

/***************************************** GetElementByValue Method ****************************************************/
	public void getElementsByValue(X data) {
		try {
			if (root == null) {
				throw new Exception("Tree is empty!");
			}
			TreeNode<X> node = findNode(data);
			if (node == null) {
				throw new Exception("Data is not present!");
			} else {
				System.out.print(node.data + ":");
				for (TreeNode<X> var : node.children) {
					System.out.print(var.data + " ");
				}
				System.out.println();
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	boolean iteratorCheck = false;

	@SuppressWarnings("rawtypes")
	@Override
	public Iterator<X> iterator() {

		if (iteratorCheck) {
			return new CustomIterator(iteratorDepth);
		} else {
			return new CustomIterator(iteratorBreadth);
		}
	}

/********************************************** Iterate Depth Function ***************************************************/
	public void iteratorDepth() {
		try {
			if (root != null) {
				getDepth(root);
				iteratorCheck = true;
				Iterator<X> iterate = iterator();
				while (iterate.hasNext()) {
					System.out.print(iterate.next() + " ");
				}
				iteratorCheck = false;
			} else {
				throw new Exception("tree is empty");
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

/************************************************ Iterate Breadth Function ***********************************************/
	public void iteratorBreadth() {
		getBreadth();
		iteratorCheck = false;
		Iterator<X> iterate = iterator();
		while (iterate.hasNext()) {
			System.out.print(iterate.next() + " ");
		}

	}

/************************************************ Get Breadth Function ***************************************************/
	private void getBreadth() {
		try {
			Queue<TreeNode<X>> queue = new Queue<>();
			queue.enqueue(root);
			while (queue.length() != 0) {

				TreeNode<X> temp = queue.dequeue();
				iteratorBreadth.enqueue(temp.data);
				for (int i = 0; i < temp.children.size(); i++) {
					ArrayList<TreeNode<X>> child = temp.children;
					queue.enqueue(child.get(i));
				}
			}
		} catch (Exception e) {

		}
	}

/*********************************************** Get Depth Function *****************************************************/
	private void getDepth(TreeNode<X> node) {

		iteratorDepth.enqueue(node.data);
		for (int i = 0; i < node.children.size(); i++) {
			ArrayList<TreeNode<X>> child = node.children;
			getDepth(child.get(i));
		}
	}
}
