package com.nagarro.javatraining.assignment5;


public abstract class Function<X> {
	
	public abstract void insert(X data,X parent);
	public abstract void delete(X data);
	public abstract void traverseDepth();
	public abstract void traverseBreadth();
	public abstract boolean contains(X data);
	public abstract void getElementsByValue(X data);
	public abstract void  getElementsByLevel(int level);
	public abstract void iteratorDepth();
	public abstract void iteratorBreadth();

}
