package com.nagarro.javatraining.assignment5;
import java.util.ArrayList;
public class TreeNode<X> {
	
    X data;
    ArrayList<TreeNode<X>> children;  //TreeNode type ArrayList
    TreeNode<X> parent;
    
    public TreeNode() {         // Default constructor
        this.parent=null;
        this.children=new ArrayList<>();
    }
    public TreeNode(X data) {    // Parameter constructor
        this.data=data;
        this.parent=null;
        this.children=new ArrayList<>();
    }

}
