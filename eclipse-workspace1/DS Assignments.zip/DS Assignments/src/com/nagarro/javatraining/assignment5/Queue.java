package com.nagarro.javatraining.assignment5;


import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Queue<T> implements Iterable<T>
{
	// to represent queue node
	class QueueNode
	{
		private T data;
		private QueueNode link;
		QueueNode(T d)
		{
			data=d;
		}
	}
	//insert from rare and delete from front
	QueueNode front=null,rare=null;
	
	//enqueue element in queue
	public void enqueue(T data)
	{
		QueueNode new_node= new QueueNode(data);
		 if((this.rare==null) || (this.front==null))
		 {
			 this.front=new_node;
			 this.rare=new_node;
		 }
		 else
		 {
			 this.rare.link=new_node;
			 this.rare=new_node;
		 }
	}
	
	//display element of queue
	public void display()
	{
		if (this.front==null)
		{
//			System.out.println("Queue is empty ");
		}
		else
		{
			QueueNode traverse= this.front;
			while(traverse != null)
			{
				System.out.print(traverse.data+" ");
				traverse=traverse.link;
			}
			System.out.println();
		}
		
	}
	
	//dequeue element of queue
	public T dequeue()
	{
		try
		{
		T dequeued_value=this.front.data;
		this.front=this.front.link;
		return dequeued_value;
		}
		catch(NullPointerException e)
		{
			return null;
		}
	
	}
	
	//peek/top element of queue
	public T peek() 
	{
		if((this.front==null)||(this.rare==null))
		{
			return null;
		}
		return this.front.data;
	}
	
	//returns true if queue contains element
	public boolean contains(T element)
	{
		QueueNode traverse= this.front;
		while(traverse != null)
		{
			if(traverse.data==element) return true;
			traverse=traverse.link;
		}
		return false;
	}
	
	//returns length of queue
	public int length()
	{
		int length=0;
		QueueNode traverse= this.front;
		while(traverse != null)
		{
			++length;
			traverse=traverse.link;
		}
		return length;
	}
	
	//reverse queue
	public void reverseQueue()
	{
		QueueNode previous=null;
		QueueNode next=this.front;
		QueueNode current=this.front;
		
		while(current != null)
		{
			next=next.link;
			current.link=previous;
			previous=current;
			current=next;
		}
		this.rare=this.front;
		this.front=previous;		
	}
	//iterator for queue
	@Override
	public Iterator<T> iterator() {
		return new QueueIterator();
	}
	class QueueIterator implements Iterator<T>
	{
		QueueNode current=null;
		QueueIterator(){
			current=front;
		}
		@Override
		public boolean hasNext() {
			return current != null;
		}
		@Override
		public T next() {
			if(current==null)
			{
				throw new NoSuchElementException();
			}
			T current_element=current.data;
			current=current.link;
			return current_element;
		}
		
	}
}