package com.nagarro.javatraining.assignment4;

import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;
public class Functions<T extends Object> {
	int maxsize;
	int size=0;
	T data[];
	
	public Functions(int maxsize) {
		this.maxsize=maxsize;
		this.data=(T[]) new Object[maxsize];
	}
	
/**************************** Implement Comparator *********************************/
	public interface Comparator<T>
	{
	    public void compare(T o1, T o2);
	}	
/******************************* Enqueue Function **********************************/
	public void enqueue(T item) {
		if (queue_size() == maxsize)
			throw new IllegalStateException("Can't enqueue because queue is full");

		else if (queue_size() == 0) {
			data[size++] = item;
		} else {
			int i;
			for (i = size - 1; i >= 0; i--) {

				Comparable ith = (Comparable) item;
				Comparable jth = (Comparable) data[i];

				if (ith.compareTo(jth) > 0)
					data[i + 1] = data[i];
				else
					break;
			}
			data[i + 1] = item;
			size++;
		}
	}
/********************************* Dequeue Function ********************************/
	public T dequeue() {
		if(size==0)
			throw new IllegalStateException ("Can't Remove because queue is Empty");
		else {
			return data[--size];
		}
	}
	
/********************************* Peek Function **********************************/
	public T peek() {
		if(size==0)
			throw new NoSuchElementException("Don't have peek because queue is empty");
		else
			return data[size-1];
	}
	
/******************************** Contains Function ********************************/
	public boolean contains(T item) {
		boolean found=false;
		if(queue_size()==0)
			return found;
		for(int i=0; i<queue_size(); i++) {
			if(data[i].equals(item)) {
				found=true;
				break;
			}
		}
		return found;
	}
	
/******************************* Reverse Function **********************************/
	public void reverse() {
		int reversed_list[]=new int[size];
		int k=0;
		for(int i=size-1; i>=0; i--) {
			reversed_list[k++]=(int) data[i];
		}
		System.out.print("Reversed List : ");
		for(int i=0; i<reversed_list.length; i++) {
			System.out.print(reversed_list[i]+" ");
		}
	}

/******************************* Iterator Function *********************************/	
	  public Iterator iterator() {
			Iterator it=new Iterator() {
			int temp=0;
			public boolean hasNext() {
				if(temp<(size))
					return true;
				return false;
			}
			
			public Object next() {
				return data[temp++];
			}
			};
			return it;
		}
	
/******************************** Print Function ***********************************/
	public void print() {
		if(queue_size()==0)
			throw new IllegalStateException("Print nothing because queue is empty");
		System.out.print("Queue Items : ");
	for(int i=0; i<size; i++)
			System.out.print(data[i]+" ");
		
	}
/********************************* Size Function ***********************************/
	public int queue_size() {
		return size;
	}
	

}
