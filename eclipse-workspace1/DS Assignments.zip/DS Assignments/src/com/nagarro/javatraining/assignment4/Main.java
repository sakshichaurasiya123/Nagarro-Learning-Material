package com.nagarro.javatraining.assignment4;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in=new Scanner(System.in);
		System.out.print("Enter Initial Size of Queue : ");
		int n=0;
		try {
		 n=in.nextInt();
		}
		catch(InputMismatchException e)
		{
			System.out.println("Number is required : Enter valid number");
			in.nextLine();
		}
		
		Functions<Integer> f=new Functions<Integer>(n);
		while(true) {
			System.out.println("1. Enqueue");
			System.out.println("2. Dequeue");
			System.out.println("3. Peek");
			System.out.println("4. Contains");
			System.out.println("5. Size");
			System.out.println("6. Reverse");
			System.out.println("7. Iterator");
			System.out.println("8. Exit");
			int choice;
			try {
				choice=in.nextInt();
			}
			catch(InputMismatchException e) {
				System.out.println("Number is requred : Enter Valid Choice");
				in.nextLine();
				continue;
			}
			switch(choice) {
			case 1:
				
				/************************** Calling Enqueue Function ********************************/
				System.out.println("Enter Items : ");
				f.enqueue(in.nextInt());
				break;
			
			case 2:
				/************************** Calling Dequeue Function ********************************/
				System.out.println("Deleted Element : "+f.dequeue());
				break;
				
			case 3:
				/*************************** Calling Peek Function **********************************/
				System.out.println("Peek Element : "+f.peek());
				break;
			
			case 4:				
				/**************************** Calling Contains Function *****************************/
				System.out.println("Enter item which you want to be check : ");
				int item=in.nextInt();
				System.out.println("Contains Element : "+f.contains(item));
				break;
				
			case 5: 
				/******************************* Calling Size Function ******************************/
				System.out.println("Size of queue : "+f.queue_size());
				break;
			
			case 6:
				/****************************** Calling Reverse Function ****************************/
				f.reverse();
				System.out.println();
				break;
				
			case 7:
				
				/***************************** Calling Iterator Function *****************************/
						System.out.print("Print Items Using �terator : ");
						for(Iterator i=f.iterator(); i.hasNext();) {
							System.out.print(i.next()+" ");
						}
						System.out.println();
						break;
						
			case 8:
				System.out.println("Terminated......");
				System.exit(0);
				break;
			
			default:
				System.out.println("Enter valid choice");
				continue;
			}
			System.out.println("Do You want to Quit Enter 0 or 1");
		     int choice1=in.nextInt();
		     if(choice1==0){   
		    	 System.out.println("Thank You");
		    	 in.close();
		    	 break;
		     
		     }
		     else{	 
		    	 continue;
		     }
		}
	}
}
