package com.nagarro.javatraining.assignment1;

class Node <T>{
	Node<T> next;
	T data;
}
