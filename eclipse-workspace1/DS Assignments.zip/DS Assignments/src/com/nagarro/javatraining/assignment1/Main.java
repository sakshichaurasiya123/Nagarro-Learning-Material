package com.nagarro.javatraining.assignment1;


import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Scanner;

public class Main {
	  
    // main driver method
    public static void main(String[] args)
    {
  
        // Integer List
  
        // Creating new empty Integer linked list
    	Scanner in=new Scanner(System.in);
        list<Integer> list = new list<Integer>();
       Node<Integer> root=null;
		int type=0,n=0;
	while(true) {
			System.out.println("Peform any operation from these given below");
			System.out.println("1. Insert At First : ");
			System.out.println("2. Insert At Last : ");
			System.out.println("3. Insert At Given Position : ");
			System.out.println("4. Delete From First Location : ");
			System.out.println("5. Delete From Last Location : ");
			System.out.println("6. Delete From Specific Location : ");
			System.out.println("7. Print Center Element From List : ");
			System.out.println("8. Print Entire List Items : ");
			System.out.println("9. Print Size of List : ");
			System.out.println("10. Print Reverse List : ");
			System.out.println("11. Iterator");
			System.out.println("12. Terminate");
			
			try{
			type=in.nextInt();
			}
			catch(InputMismatchException e) {
				System.out.println("Number is required : ENTER VALID NUMBER");
				type=in.nextInt();
				continue;
			}
			
			switch (type) {
			
			case 1:
				int item;
				try {
				 item=in.nextInt();
				}
				catch(InputMismatchException e) {
					System.out.println("Number is required : ENTER VALID INPUT");
					item=in.nextInt();
					continue;
				}
				root=list.insert_at_First(root, item);
				System.out.println("After Inserted Element on First Location");
				list.print_list_item(root);
				break;

			case 2:
				int item1;
				try {
					item1=in.nextInt();
				}
				catch(InputMismatchException e) {
					System.out.println("Number is requied : ENTER VALID INPUT");
					item1=in.nextInt();
					continue;
				}
				root=list.insert_at_last(root, item1);
				System.out.print("List After Inserted Element on Last Location : ");
				list.print_list_item(root);
				break;
			case 3:
				int position,item3;
				System.out.println("Enter Item and the position : ");
				try {
					item3=in.nextInt();
				}
				catch(InputMismatchException e) {
					System.out.println("Number is requied : ENTER VALID INPUT");
					item3=in.nextInt();
					continue;
				}
				try {
					position=in.nextInt();
				}
				catch(InputMismatchException e) {
					System.out.println("Numbe is required : ENTER VALID INPUT");
					position=in.nextInt();
					continue;
				}
				root=list.insert_at_given_position(root, item3, position);
				System.out.print("List After inserted Element on Specific Position : ");
				list.print_list_item(root);
				break;
				
			case 4:
				root=list.delete_Front(root);
				System.out.print("List After deleted Element from First Location :  ");
				list.print_list_item(root);
				break;
			case 5: 
				root=list.delete_last(root);
				System.out.print("List After Deleted Element from Last Location : ");
				list.print_list_item(root);
				break;
			case 6:
				int p;
				try {
					System.out.println("Enter position from which you want to delete element : ");
					p=in.nextInt();
				}
				catch(InputMismatchException e) {
					System.out.println("Numbe is required : ENTER VALID INPUT");
					p=in.nextInt();
					continue;
				}
				
				
				root=list.delete_from_given_pos(root, p);
				System.out.print("List After Deleted Element from Given Position : ");
				list.print_list_item(root);
				break;
			case 7: 
				list.calculateCenter(root);
				break;
			case 8:
				System.out.print("Entire List Items : ");
				list.print_list_item(root);
				break;
				
			case 9:
				int size=list.list_size(root);
				System.out.println("List Size : "+size);
				break;
				
			case 10:
				root=list.reverse_iteratively(root);
				System.out.println("Reversed List Item : ");
				list.print_list_item(root);
				break;
			case 11:
				System.out.print("Entire List Using Iterator : ");
				for(Iterator i=list.iterator(root); i.hasNext();) {
					System.out.print(i.next()+" ");
				}
				System.out.println();
				break;
				
			case 12:
				System.out.println("Terminated.....");
				System.exit(0);
			
			default :
				System.out.println("Please Enter Valid type, type can be only from 1-12");
			}
			
			System.out.println("Do You want to Quit Enter 0 or 1");
		     int choice1=in.nextInt();
		     if(choice1==0){   
		    	 System.out.println("Thank You");
		    	 in.close();
		    	 break;
		     
		     }
		     else{	 
		    	 continue;
		     }
		}
	}
}