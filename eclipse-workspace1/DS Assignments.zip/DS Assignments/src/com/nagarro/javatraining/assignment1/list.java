package com.nagarro.javatraining.assignment1;

import java.util.Iterator;
import java.util.NoSuchElementException;

class list<T>{
 Node<T> root;
    
/*******************************Create New Node********************************/
    private Node<T> createNewNode(T item) {
		Node<T> d=new Node<T>();
		d.data=item;
		d.next=null;
		return d;
	}
	
/****************************Insert Operation********************************/
	public Node<T> insert(Node<T> root,T item) {
		if(root==null)
			return createNewNode(item);
		else {
			root.next=insert(root.next,item);
		}
		return root;
	}	
	
	
/************************Insert At First Position****************************/
	public Node insert_at_First(Node root,T i) {
		Node temp=new Node();
		if(root==null)
			return createNewNode(i);
		else {
			 temp.data=i;
			temp.next=root;
		}
		return temp;
	}
	
/******************* Insert At Last Position ********************************/
	public Node insert_at_last(Node root,T item) {
		Node temp=root;
		Node newNode=new Node();
		newNode.data=item;
		newNode.next=null;
		if(root==null)
			return createNewNode(item);
		else {
			while(temp.next!=null) {
				temp=temp.next;
			}
			temp.next=newNode;
		}
		return root;
	}
	
/****************************Print List Items***********************************/
	public void print_list_item(Node<T> root) {
		if(root==null)
			return;
		System.out.print(root.data+" ");
		print_list_item(root.next);
		System.out.println();
	}
		
/*************************** Print List Size ************************************/
	public int list_size(Node<T> root) {
		int size=0;
		if(root==null)
		{
			throw new NullPointerException("List is Empty");
		}
			Node<T> temp=root;
			while(temp!=null) {
				temp=temp.next;
				size++;
			}
			return size;
	}

/*************************** Insert at Given Position *************************/
	public Node insert_at_given_position(Node<T> root,T i, int p) {
		Node<T> temp=root;
		Node<T> newNode=new Node<T>();
		newNode.data=i;
		if(p==1) {
			newNode.next=temp;
			return newNode;
		}
		else if(root==null && p!=0) {
			throw new IllegalStateException("Invalid Position");
		}
		else if(root==null && p==0)
			createNewNode(i);
		else if(p>(list_size(root)+1) || p<0) {
			throw new IllegalStateException("Position can't be negative | can't be larger than size+1");
		}
		else {
			for(int k=1; k<(p-1); k++) {
				temp=temp.next;
			}
			newNode.next=temp.next;
			temp.next=newNode;
			
		}
		return root;
	}

/*********************** Delete First Item ***************************************/
		public Node delete_Front(Node<T> root) {
			if(root==null)
				return null;
			return root.next;
		}
		
/************************ Delete Last Item ************************************/
		public Node delete_last(Node<T> root) {
			if(root==null || root.next==null)
				return null;
			Node temp=root;
			while(temp.next.next!=null) {
				temp=temp.next;
			}
			temp.next=null;
			return root;
		}
		
/******************** Delete Item from Specific Position *********************/
		public Node delete_from_given_pos(Node<T> root,int p) {
			Node temp=root;
			if(root==null)
			{
				throw new NullPointerException("List is Empty you can't remove elements");
			}
			else if(p>(list_size(root))) {
				throw new IllegalStateException("Invalid Position = "+p);
			}
			else if(p<=0)
			{
				throw new IllegalStateException("Position can't be negative ");
			}
			else {
				int i=1;
				while(i<(p-1) && temp.next!=null) {
					temp=temp.next;
					i++;
				}
				temp.next=temp.next.next;
			}
				
			return root;
		}
		
/************************** Reverse List **************************************/
		public Node reverse_iteratively(Node<T> root) {
			Node curr=root;
			Node prev=null;
			Node next=null;
			while(curr!=null) {
			next=curr.next;
			curr.next=prev;
			prev=curr;
			curr=next;
			}
			return prev;
		}
		
/***************** Calculate center element from given list *****************/
		public void calculateCenter(Node<T> root) {
			Node first,second;
			first=second=root;
			if (root==null) {
				throw new NullPointerException("List is Empty ");
			}
			else {
			while(second!=null && second.next!=null) {
				
				second=second.next.next;
				first=first.next;
			}
			System.out.println(first.data);
			}
		}
		
/********************************* Iterator ***********************************************/
		public Iterator iterator(Node root1) {
			Iterator it=new Iterator() {
			Node currentNode=root1;
			public boolean hasNext() {
				return currentNode!=null; 
			}
			
			public Object next() {
				Node node=currentNode;
				currentNode=currentNode.next;
				return node.data;
			}
		};
		return it;
		}
}
