package com.nagarro.javatraining.assignment6;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Scanner;

/********************************************** Main Class ***************************************************/
public class Main {
	public static void main(String[] args)
	{	String key;
	int value;
		Map map=new Map();
		Scanner sc=new Scanner(System.in);
	     while(true)
	     {
	    	 	System.out.println("Enter Your Choice ");
				System.out.println("1. Insert ");
				System.out.println("2. Delete ");
				System.out.println("3. Cointain ");
				System.out.println("4. Get Vaue by Key ");
				System.out.println("5. Size ");
				System.out.println("6. Iterator ");
				System.out.println("7. Print");
				int choice=0;
				try {
					choice = sc.nextInt();
				}
				catch(InputMismatchException e)
				{
					System.out.println("Number is required : INVALID INPUT ");
					sc.nextLine();
					continue;
				}

	     switch(choice)
	     {
	     case 1:
	    	 System.out.println("Enter the Key and Value");
	    	 key=sc.next();
	    	 try {
	    		 value=sc.nextInt();
				}
				catch(InputMismatchException e1)
				{
					System.out.println("Number is required : INVALID INPUT ");
					sc.nextLine();
					continue;
				}
	    	
             map.insert(key,value);  
             System.out.println("Inserted");
	    	 break;
	     case 2:
	    	 System.out.println("Enter the Key");
	    	 key=sc.next();
	    	 if((map.delete(key)==0))
	    			 System.out.println("Key is not Present");
	    	 else
	    		 System.out.println(key+" is deleted ");
	    	 break;
	     case 3:
	    	 System.out.println("Enter the Key");
	    	 key=sc.next();
	    	System.out.println("Key Contains : "+map.Contains(key));
	    
	    	 break;
	     case 4:
	    	 System.out.println("Enter the Key");
	    	 key=sc.next();
	    	 if(map.getValue(key)==0)
    			 System.out.println("Key is not Present");
	    	 else
	    		 System.out.println("Value: "+map.getValue(key));
	    	 break;
	     case 5:
	         System.out.println("The HashTable size is " + map.size());
	         break;
	     case 6:
	    	 System.out.println("Using Iterator");
	    	  Iterator it=map.iterator();
	    	  while(it.hasNext())
	    	  {
	    		  System.out.println(it.next()+" ");
	    	  }
	    	 break;
		 case 7:
			 System.out.println("Entire Key values of HashTable ");
			 map.PrintHashTable();
	    	 break;
	     default:
	    	 System.out.println("Invalid Option PLEASE TRY AGAIN");
	    	 continue;
	     }
	     System.out.println("Do You want to Quit Enter 0 or 1");
	     int choice1=sc.nextInt();
	     if(choice1==0){   
	    	 System.out.println("Thank You");
	    	 sc.close();
	    	 break;
	     
	     }
	     else{	 
	    	 continue;
	     }
	     
	}
		
	}

}