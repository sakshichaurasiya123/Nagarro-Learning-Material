package com.nagarro.javatraining.assignment6;

import java.util.InputMismatchException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
class HashNode{
 String key;
 int value;

 HashNode next;

/********************************************* Constructor ****************************************************/
 public HashNode(String key, int value)
 {
     this.key = key;
     this.value = value;
 }

}

/*********************************************** Map Class *****************************************************/
class Map<K, V> {
 private static ArrayList<HashNode> arr;

 private static int capacity=10;

 private int size;
 
 String keys[]=new String[capacity];
 
/******************************************** Map Constructor **************************************************/
 public Map()
 {
     arr = new ArrayList<>();
     size = 0;

     for (int i = 0; i < capacity; i++)
    	 arr.add(null);
 }

 /**************************************** Size Function *****************************************************/
 public int size() { return size; }
 
 /*************************************** IsEmpty Function ***************************************************/
 public boolean isEmpty() { return size() == 0; }
 
/*************************************** Method for getting index **********************************************/
 private static int getIndex(String key)
 {
     int hashCode = key.hashCode();
     int index = hashCode % capacity;
     
     index = index < 0 ? index * -1 : index;
     return index;
 }

/*********************************Method for deleting key ****************************************************/
 public int delete(String key)
 {
     int Index = getIndex(key);

     HashNode head = arr.get(Index);

     HashNode prev = null;
     while (head != null) {
         
         if (head.key.equals(key))
             break;
         prev = head;
         head = head.next;
     }

     if (head == null)
         return 0;
     size--;
     if (prev != null)
         prev.next = head.next;
     else
    	 arr.set(Index, head.next);

     return head.value;
 }

 /*********************************************** getValue Function **********************************************/
 public static int getValue(String key)
 {
     int Index = getIndex(key);
     HashNode head = arr.get(Index);
    
     while (head != null) {
         if (head.key.equals(key))
         {
             return head.value;
         }
         head = head.next;
     }

     return 0;
 }

 /********************************************* Insert Function ************************************************/
 public void insert(String key, int value)
 {
     int Index = getIndex(key);
     HashNode head = arr.get(Index);

     while (head != null) {
         if (head.key.equals(key)) {
             head.value = value;
             return;
         }
         head = head.next;
     }

     size++;
     keys[size]=(String) key;
     head = arr.get(Index);
     HashNode newNode
         = new HashNode (key, value);
     newNode.next = head;
     arr.set(Index, newNode);
     
     if ((1.0 * size) / capacity >= 0.7) {
         ArrayList<HashNode > temp = arr;
         arr = new ArrayList<>();
         capacity = 2 * capacity;
         size = 0;
         for (int i = 0; i < capacity; i++)
        	 arr.add(null);

         for (HashNode headNode : temp) {
             while (headNode != null) {
                 insert(headNode.key, headNode.value);
                 headNode = headNode.next;
             }
         }
     }
 }
/***************************************** Contains Method ********************************************************/
public boolean Contains(String key){
    int Index = getIndex(key);
    HashNode head = arr.get(Index);

    while (head != null) {
        if (head.key.equals(key))
            return true;
        head = head.next;
    }

    return false; 
   }
/******************************************** Iterator Function ***************************************************/
 public  Iterator iterator() {
		Iterator it = new Iterator() {
			
			
			int temp=0;
			@Override
			public boolean hasNext() {
				return temp !=size;
			}

			@Override
			public Object next() {
				temp=temp+1;
				String key=keys[temp];
				return "Key: "+key+"  ,  Value: "+Map.getValue(key);
			
			}
			
		};
		
		return it;
	}
 /************************************** Method for Printing HashTable ****************************************/
void PrintHashTable() {
	for(int i=1;i<=size;i++)
	{	
		String key=keys[i];
		System.out.println("Key: "+key+" Value: "+Map.getValue(key));
	}

}
}
