package com.nagarro.javatraining.assignment3;
import java.util.Iterator;
public class Queue_Function <T extends Object> {
	int front=-1;
	int rear=-1;
	int maxsize;
	private T data[];
	private T reversed_Array[];
	
	public Queue_Function(int size) {
		this.maxsize=size;
		this.data=(T[]) new Object[maxsize];
	}
	
/**************************** Enqueue Function **************************************/
	public void enqueue(T item) {
		if((rear+1)%data.length==front) {
			throw new IllegalStateException("queue is full");
		}
		else if(queue_size()==0){
			rear=(rear)%data.length;
			front++;
			rear++;
			data[rear]=item;
		
		}
		else {
			rear=(rear)%data.length;
			rear++;
			data[rear]=item;
		}
	
	}
	
/**************************** Dequeue Function ***************************************/
	public T dequeue() {
		T item;
		if(queue_size()==0)
			throw new IllegalStateException("Can't dequeue because the queue is empty");
		else if(front==rear) {
			item=data[front];
			front=-1;
			rear=-1;
		}
		else {
			
			item=data[front];
			front++;
		}
		return item;
	}
	
/***************************** Size Function *************************************/
	public int queue_size() {
		if(front==-1 && rear==-1) {
			return 0;
		}
		return rear-front+1;
	}
	
/************************** Contains Function ************************************/
	public boolean contains(T item) {
		boolean found=false;
		if(queue_size()==0)
			return found;
		for(int i=front; i<=rear; i++) {
			if(data[i]==item) {
				found=true;
				break;
			}
		}
		return found;
	}
/***************************** Peek Function *************************************/
	public T peek() {
		if(queue_size()==0) {
			throw new IllegalStateException("Doesn't have peek because queue is empty");
		}
		else {
			return data[front];
		}
	}
	
/***************************** Print Function ***********************************/
	public void print() {
		if(queue_size()==0)
 			throw new IllegalStateException("Print nothing because queue is empty");
		else {
			System.out.print("Queue Items : ");
			for(int i=front; i<=rear; i++)
				System.out.print(data[i]+" ");
		}
		System.out.println();
	}
	
/*************************** Reverse Function ************************************/
	public void reverse() {
		this.reversed_Array=(T[]) new Object[queue_size()];

		int ri=0;
		for(int i=rear; i>=front; ) {
			reversed_Array[ri++]=data[i--];
		}
		System.out.print("Reversed List of Queue Items : ");
		for(int i=0; i<reversed_Array.length; i++)
			System.out.print(reversed_Array[i]+" ");
	}
/*************************** Iterator Function ***********************************/	
	public Iterator iterator() {
		Iterator it=new Iterator() {
		int temp=front;
		public boolean hasNext() {
			return temp!=rear+1;
		}
		
		public Object next() {
			return data[temp++];
		}
		};
		return it;
	}
}