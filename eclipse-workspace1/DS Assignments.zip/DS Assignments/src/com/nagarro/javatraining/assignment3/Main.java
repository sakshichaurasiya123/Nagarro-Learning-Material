package com.nagarro.javatraining.assignment3;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Scanner;

public class Main {
	public static void main(String arg[]) {
		Scanner in=new Scanner(System.in);
		System.out.print("Enter Initial Size of Queue : ");
		int size=in.nextInt();
		Queue_Function<Integer> qf=new Queue_Function<Integer>(size);
		
		while(true) {
			System.out.println("1. Enqueue");
			System.out.println("2. Dequeue");
			System.out.println("3. Peek");
			System.out.println("4. Contains");
			System.out.println("5. Size");
			System.out.println("6. Reverse");
			System.out.println("7. Iterator");
			System.out.println("8. Traverse/Print");
			System.out.println("9. Terminate");
			int choice;
			try {
				choice=in.nextInt();
			}
			catch(InputMismatchException e) {
				System.out.println("Number is required : Enter valid number");
				in.nextLine();
				continue;
			}
			switch(choice) {
			case 1:
				
				/*************************** Calling Enqueue Function ****************************/
				System.out.println("Enter items : ");
				qf.enqueue(in.nextInt());
				break;

			case 2:
				
				/************************** Calling Dequeue Function *****************************/
						System.out.println("Removed Item : "+qf.dequeue());
					break;
			case 3:
				
				/***************************** Calling Peek Function *****************************/
						System.out.println("Peek Element : "+qf.peek());
				break;
			
			case 4:
				/*************************** Calling Contains Function ***************************/
				System.out.print("Enter Item which you want to be check : ");
				int item=in.nextInt();
				System.out.println("Contains Item : "+qf.contains(item));
				break;
			
			case 5:
				
				/************************** Calling Size Function ********************************/
				System.out.println("Queue Size : "+qf.queue_size());
				break;
						
			case 6:
				/*********************** Calling Reverse Function ********************************/
				qf.reverse();
				System.out.println();
				break;
			
			case 7:
				
				/*********************** Calling Iterator Function ********************************/
				System.out.print("Print Items Using �terator : ");
					for(Iterator i=qf.iterator(); i.hasNext();) {
						System.out.print(i.next()+" ");
					}
					System.out.println();
					break;
				
			case 8:
				
				/*********************** Calling Print Function **********************************/
				qf.print();
				break;
			
			case 9:
				System.out.println("Terminated......");
				break;	
			
			default:
				System.out.println("Enter Valid Choice");
				continue;
			}
			System.out.println("Do You want to Quit Enter 0 or 1");
		     int choice1=in.nextInt();
		     if(choice1==0){   
		    	 System.out.println("Thank You");
		    	 in.close();
		    	 break;
		     
		     }
		     else{	 
		    	 continue;
		     }
		}
		
	}
	

	
}
