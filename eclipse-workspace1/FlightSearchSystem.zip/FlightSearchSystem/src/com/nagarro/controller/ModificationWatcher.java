package com.nagarro.controller;

import com.nagarro.listoffile.ListOfFile;

import java.util.ArrayList;

public class ModificationWatcher implements Runnable{


    public void run()
    {

        ArrayList<String> l = new ArrayList<String>();
    int i=0;
    while (i< ListOfFile.filenames.size()) {
        if(!(l.contains(ListOfFile.filenames.get(i)))){
            l.add(ListOfFile.filenames.get(i));
          // System.out.println(ListOfFile.filenames);
    }
        ArrayList <String > fname = new ArrayList<String>() ;
        fname.addAll(ListOfFile.filenames);

        if(fname.size()==l.size())
            return ;
        for (String string : fname) {
            if (!(l.contains(string)))
            {
                fname.remove(string);
                synchronized(MainUtil.flightsInfo)
                {
                    MainUtil.flightsInfo.remove(string);
                }
//		System.out.println("Removing file : " + string);
            }
        }
    }
}


    }


