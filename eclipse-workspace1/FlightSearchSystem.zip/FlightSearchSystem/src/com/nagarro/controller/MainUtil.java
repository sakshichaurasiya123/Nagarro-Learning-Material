package com.nagarro.controller;
import com.nagarro.input.InputAcceptor;
import com.nagarro.input.InputReader;
import com.nagarro.model.Flight;
import com.nagarro.model.FlightDurationComparator;
import com.nagarro.model.FlightPriceComparator;
import com.nagarro.model.UserInput;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class MainUtil {

    public static ArrayList<Flight> flightsInfo = new ArrayList<Flight>();

    public static void main(String[] args) throws Exception {
        ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor();
       service.scheduleAtFixedRate(new ModificationWatcher(), 0, 3, TimeUnit.SECONDS);
        Scanner sc = new Scanner(System.in);
        InputReader ir = new InputReader();
        ir.csvreader();
        ArrayList<Flight> result = new ArrayList<Flight>();
        String choice;
        UserInput uiObj;
        do {
            uiObj = InputAcceptor.enterInput();
            result.clear();
            synchronized (MainUtil.flightsInfo) {
                for (Flight f : flightsInfo) {
                    if (f.getDepLoc().equalsIgnoreCase(uiObj.getDepLoc())
                            && f.getArrLoc().equalsIgnoreCase(uiObj.getArrLoc())
                            && f.getFlightClass().equalsIgnoreCase(uiObj.getFlightClass())
                            && (uiObj.getFlightDate().compareTo(f.getValidTill()) <= 0)
                            && f.isSeatAvailability())
                        result.add(f);
                }

            }
            if (uiObj.getOutputPreference() == 1)
                Collections.sort(result, new FlightPriceComparator());
            else
                Collections.sort(result, new FlightDurationComparator());
            if (result.size() == 0) {
                System.out.println("Sorry! No flight available");

            } else {
                System.out.println("\nResult:");
                for (Flight f : result) {
                    System.out.println(f);
                }}
                System.out.print("\nWant to Exit (Enter Y/N)");
                choice = sc.next();
                if ((choice.equalsIgnoreCase("n"))) {
                    System.out.print("Thank You");
                    service.shutdown();
                }
            }
            while (choice.equalsIgnoreCase("y")) ;
            service.shutdown();

    }

        }











