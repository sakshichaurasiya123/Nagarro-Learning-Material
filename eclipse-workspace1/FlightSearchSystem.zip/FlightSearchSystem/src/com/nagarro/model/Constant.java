package com.nagarro.model;

import java.text.SimpleDateFormat;

public interface Constant {
    public static SimpleDateFormat dateformat = new SimpleDateFormat("dd-MM-yyyy");
}
