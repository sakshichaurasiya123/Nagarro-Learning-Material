package com.nagarro.controller;

import com.nagarro.model.Searchable;
import com.nagarro.processing.InputReader;
import com.nagarro.service.Constant;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class Main implements Constant {

    public static void main(String[] args) throws Exception {

        ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor();
        service.scheduleAtFixedRate(new ModificationWatcher(), 0, 3, TimeUnit.SECONDS);
        em.getTransaction().begin();

        InputReader ir = new InputReader();
        ir.csvreader(em);

        em.getTransaction().commit();
        Searchable.search();
        mf.close();
        service.shutdown();

    }
}
