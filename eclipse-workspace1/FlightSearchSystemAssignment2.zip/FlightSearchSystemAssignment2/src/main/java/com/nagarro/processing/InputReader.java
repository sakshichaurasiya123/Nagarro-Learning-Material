package com.nagarro.processing;

import au.com.bytecode.opencsv.CSVReader;
import com.nagarro.service.Constant;
import com.nagarro.model.Flight;


import javax.persistence.EntityManager;
import java.io.File;
import java.io.FileReader;
import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.StringTokenizer;


public class InputReader implements Constant {
    public void csvreader(EntityManager em) throws Exception {
       // System.out.println("Hello!");
        ListOfFile files = new ListOfFile();
        String base = "src\\main\\resources\\CSV";
        final File folder1 = new File(base);
        List<String> flight = files.listFilesForFolder(folder1);
        //System.out.println(flight);
        for (String str : flight) {
            String path = base + "\\"+ str;
            //System.out.println(path);
            CSVReader reader = new CSVReader(new FileReader(path), ',', '\'', 1);
            //List<Flight> fl = new ArrayList<Flight>();
            String[] record = null;

            while ((record = reader.readNext()) != null) {

                StringTokenizer st = new StringTokenizer(record[0], "|");


                String flightNo = st.nextToken();
                String depLoc = st.nextToken();
                String arrLoc = st.nextToken();

                String validTillDate = st.nextToken();
                Date validTill = new Date();
                try {
                    validTill = dateformat.parse(validTillDate);
                } catch (ParseException e) {
                    System.err.print("Date not in appropriate(dd-MM-yyyy) format");
                }

                String flightTime = st.nextToken();
                Double flightDuration = Double.parseDouble(st.nextToken());
                int fare = Integer.parseInt(st.nextToken());

                String avail = st.nextToken();
                Boolean seatAvailability;
                if (avail.charAt(0) == 'Y')
                    seatAvailability = true;
                else
                    seatAvailability = false;

                String flightClass = st.nextToken();
                //System.out.println(flightClass);
                Flight f1 =  new Flight(flightNo, depLoc, arrLoc, fare, validTill,
                        flightTime, flightDuration, seatAvailability, flightClass);
                em.persist(f1);


            }

        }


    }
}


