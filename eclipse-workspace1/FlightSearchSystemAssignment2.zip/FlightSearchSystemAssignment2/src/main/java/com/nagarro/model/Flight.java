package com.nagarro.model;

import com.nagarro.service.Constant;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


@Entity
@Table(name = "flight")
public class Flight implements Constant, Serializable {
        @Id
        @GeneratedValue(strategy = GenerationType.AUTO)
        Long id;
        String flightNo;
        String depLoc;
        String arrLoc;
        Date validTill;
        String flightTime;
        Double flightDuration;
        int fare;
        boolean seatAvailability;
        String flightClass;

        public Flight(String flightNo, String depLoc, String arrLoc, int fare, Date validTill, String flightTime,
                      Double flightDuration, boolean seatAvailability, String flightClass) {
            super();
            this.flightNo = flightNo;
            this.depLoc = depLoc;
            this.arrLoc = arrLoc;
            this.validTill = validTill;
            this.flightTime = flightTime;
            this.flightDuration = flightDuration;
            this.seatAvailability = seatAvailability;
            this.flightClass = flightClass;
            if (flightClass.equalsIgnoreCase("EB"))
                fare = 140 * fare / 100;
            this.fare = fare;
        }

        public Flight() {

        }

        public String getFlightNo() {
            return flightNo;
        }

        public void setFlightNo(String flightNo) {
            this.flightNo = flightNo;
            //return flightNo;
        }

        public String getDepLoc() {
            return depLoc;
        }

        public void setDepLoc(String depLoc) {
            this.depLoc = depLoc;
            //return depLoc;
        }

        public String getArrLoc() {
            return arrLoc;
        }

        public void setArrLoc(String arrLoc) {
            this.arrLoc = arrLoc;
            //return arrLoc;
        }

        public Date getValidTill() {
            return validTill;
        }

        public void setValidTill(Date validTill) {
            this.validTill = validTill;
        }

        public String getFlightTime() {
            return flightTime;
        }

        public void setFlightTime(String flightTime) {
            this.flightTime = flightTime;
        }

        public Double getFlightDuration() {
            return flightDuration;
        }

        public void setFlightDuration(Double flightDuration) {
            this.flightDuration = flightDuration;
        }

        public int getFare() {
            return fare;
        }

        public void setFare(int fare) {
            this.fare = fare;
        }

        public boolean isSeatAvailability() {
            return seatAvailability;
        }

        public void setSeatAvailability(boolean seatAvailability) {
            this.seatAvailability = seatAvailability;
        }

        public String getFlightClass() {
            return flightClass;
        }

        public void setFlightClass(String flightClass) {
            this.flightClass = flightClass;
        }

        @Override
        public String toString() {
            return "flightNo=" + flightNo + ", depLoc=" + depLoc + ", arrLoc=" + arrLoc + ", validTill="
                    + dateformat.format(validTill) + ", flightTime=" + flightTime + ", flightDuration="
                    + String.format("%.2f", flightDuration) + ", fare=" + fare + ", seatAvailability=" + seatAvailability
                    + ", flightClass=" + flightClass;
        }

        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((flightNo == null) ? 0 : flightNo.hashCode());
            return result;
        }

        public boolean equals(Object obj) {
            Flight other = (Flight) obj;
            if (arrLoc == null) {
                if (other.arrLoc != null)
                    return false;
            } else if (!arrLoc.equals(other.arrLoc))
                return false;
            if (depLoc == null) {
                if (other.depLoc != null)
                    return false;
            } else if (!depLoc.equals(other.depLoc))
                return false;
            if (flightNo == null) {
                if (other.flightNo != null)
                    return false;
            } else if (!flightNo.equals(other.flightNo))
                return false;
            if (flightTime == null) {
                if (other.flightTime != null)
                    return false;
            } else if (!flightTime.equals(other.flightTime))
                return false;
            if (seatAvailability != other.seatAvailability)
                return false;
            if (validTill == null) {
                if (other.validTill != null)
                    return false;
            } else if (!validTill.equals(other.validTill))
                return false;
            return true;
        }

    }


