package com.nagarro.processing;


import com.nagarro.service.Constant;
import com.nagarro.model.UserInput;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Date;

public class InputAcceptor implements Constant {
    public static UserInput enterInput() throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String source, destination, flightClass;
        int outputPreference;
        Date flightDate = null;


        System.out.print("DEPARTURE LOC: ");

        while ((source = UserInputValidator.validateSource(br.readLine())) == null) {
            continue;
        }

        System.out.print("ARRIVAL LOC: ");
        while ((destination = UserInputValidator.validateDestination(br.readLine())) == null) {
            continue;
        }

        System.out.print("Flight Class:(E/EB)");
        while ((flightClass = UserInputValidator.validateFlightClass(br.readLine())) == null) {
            continue;
        }

        System.out.print("Date Of Travel(DD-MM-YYYY): ");
        while ((flightDate = UserInputValidator.validateDate(br.readLine())) == null) {
            continue;
        }

        System.out.print("Output preference(Sort by Fare/Duration)):\n(Enter 1/2): ");
        while ((outputPreference = UserInputValidator
                .validateOutputPreference(Integer.parseInt(br.readLine()))) == 0) {
            continue;
        }

        return new UserInput(source, destination, flightDate,
                flightClass, outputPreference);
    }
}
