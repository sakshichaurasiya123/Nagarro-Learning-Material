package com.nagarro.model;
import com.nagarro.processing.InputAcceptor;
import com.nagarro.service.Constant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Searchable implements Constant {

    public static void search() throws Exception {

        Scanner sc = new Scanner(System.in);
        ArrayList<Flight> result = new ArrayList<Flight>();
        String choice;
        UserInput uiObj;
        do {
            uiObj = InputAcceptor.enterInput();
            //result.clear();
            List<Flight> all = em.createNativeQuery("select * from flight",Flight.class).getResultList();

            for(Flight f: all){
                //System.out.println(j.toString());

                if (f.getDepLoc().equalsIgnoreCase(uiObj.getDepLoc())
                        && f.getArrLoc().equalsIgnoreCase(uiObj.getArrLoc())
                        && f.getFlightClass().equalsIgnoreCase(uiObj.getFlightClass())
                        && (uiObj.getFlightDate().compareTo(f.getValidTill()) <= 0)
                        && f.isSeatAvailability())
                    result.add(f);

            }
            if (uiObj.getOutputPreference() == 1)
                Collections.sort(result, new FlightPriceComparator());
            else
                Collections.sort(result, new FlightDurationComparator());
            if (result.size() == 0) {
                System.out.println("Sorry! No flight available");

            } else {
                System.out.println("\nResult:");
                for (Flight f : result) {
                    System.out.println(f);
                }}
            System.out.print("\nWant to Continue (Enter Y/N)");
            choice = sc.next();
            if ((choice.equalsIgnoreCase("n"))) {
                System.out.print("Thank You");
            }
        }
        while (choice.equalsIgnoreCase("y")) ;
    }
}
