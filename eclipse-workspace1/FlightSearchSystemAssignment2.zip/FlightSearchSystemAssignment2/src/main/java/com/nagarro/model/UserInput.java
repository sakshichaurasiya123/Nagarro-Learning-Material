package com.nagarro.model;

import java.util.Date;

public class UserInput {
    String depLoc;
    String arrLoc;
    Date flightDate;
    String flightClass;
    int outputPreference;

    /**
     * @param depLoc
     * @param arrLoc
     * @param flightDate
     * @param flightClass
     * @param outputPreference
     */
    public UserInput(String depLoc, String arrLoc, Date flightDate, String flightClass, int outputPreference) {
        this.depLoc = depLoc;
        this.arrLoc = arrLoc;
        this.flightDate = flightDate;
        this.flightClass = flightClass;
        this.outputPreference = outputPreference;
    }

    public String getDepLoc() {
        return depLoc;
    }

    public void setDepLoc(String depLoc) {
        this.depLoc = depLoc;
    }

    public String getArrLoc() {
        return arrLoc;
    }

    public void setArrLoc(String arrLoc) {
        this.arrLoc = arrLoc;
    }

    public Date getFlightDate() {
        return flightDate;
    }

    public void setFlightDate(Date flightDate) {
        this.flightDate = flightDate;
    }

    public String getFlightClass() {
        return flightClass;
    }

    public void setFlightClass(String flightClass) {
        this.flightClass = flightClass;
    }

    public int getOutputPreference() {
        return outputPreference;
    }

    public void setOutputPreference(int outputPreference) {
        this.outputPreference = outputPreference;
    }

    @Override
    public String toString() {
        return "UserInput [depLoc=" + depLoc + ", arrLoc=" + arrLoc + ", flightDate=" + flightDate + ", flightClass="
                + flightClass + ", outputPreference=" + outputPreference + "]";
    }

}
