package com.nagarro.processing;

import java.io.File;
import java.util.LinkedList;
import java.util.List;

public class ListOfFile {
    public  static  List<String> filenames = new LinkedList<String>();
    public static List<String> listFilesForFolder(final File folder) {

        for (final File fileEntry : folder.listFiles()) {
            if (fileEntry.isDirectory()) {
                listFilesForFolder(fileEntry);
            }

            else {
                if(fileEntry.getName().contains(".csv"))
                    filenames.add(fileEntry.getName());
            }
        }
        //System.out.println(filenames);
        return filenames;
    }
}
