package com.nagarro.processing;

import com.nagarro.service.Constant;

import java.text.ParseException;
import java.util.Date;
import java.util.List;


public class UserInputValidator implements Constant {
    public static Date validateDate(String str)
    {
        dateformat.setLenient(false);
        Date validTill = null;
        try {
            validTill =  dateformat.parse(str);
        } catch (ParseException e) {
            System.err.print("Date not in appropriate(dd-MM-yyyy) format, Enter Again: ");
        }
        return validTill ;
    }

    public static String validateSource(String src) {
        List<String> l1 =  em.createQuery("select distinct depLoc from Flight").getResultList();
        //System.out.println(l1);
            for(String s : l1){
                //System.out.println(s);
                if(s.equalsIgnoreCase(src)){
                    return s;
                }
            }


        System.err.print("Flights from no such stations found, Kindly Enter Again: ");
        return null;
    }

    public static String validateDestination(String destination) {
        List<String> l1 =  em.createQuery("select distinct arrLoc from Flight").getResultList();

        for(String s : l1){
           // System.out.println(s);
            if(s.equalsIgnoreCase(destination)){
                return s;
            }
        }
        System.err.print("Flights to no such stations found, Kindly Enter Again: ");
        return null;
    }

    public static String validateFlightClass(String str) {
        if (str.equalsIgnoreCase("E")||str.equalsIgnoreCase("EB"))
            return str.toUpperCase() ;
        else
        {
            System.err.print("Flight Class entered Inappropriately, Enter Again :");
            return null;
        }
    }

    public static int validateOutputPreference(int i) {
        if((i==1)||(i==2))
            return i ;
        else
        {
            System.err.print("Output preference entered Inappropriately, Enter Again : ");
            return 0;
        }
    }

}
