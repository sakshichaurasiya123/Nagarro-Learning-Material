package com.nagarro.service;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.text.SimpleDateFormat;

public interface Constant {
    public static SimpleDateFormat dateformat = new SimpleDateFormat("dd-MM-yyyy");

    EntityManagerFactory mf = Persistence.createEntityManagerFactory("simple_api");

    EntityManager em = mf.createEntityManager();


}
